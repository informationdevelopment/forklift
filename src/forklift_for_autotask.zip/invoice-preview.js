window.addEventListener("pageshow", function() {
    const previewWatermark = document.querySelector('div');
    previewWatermark.style.zIndex = -1;
});
